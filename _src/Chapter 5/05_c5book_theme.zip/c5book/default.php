<?php
defined('C5_EXECUTE') or die('Access Denied.');
$this->inc('elements/header.php');
?>

<div id="content">
    <?php
    $b = new Area('Main');
    $b->display($c);
    ?>
</div>

<?php $this->inc('elements/footer.php'); ?>

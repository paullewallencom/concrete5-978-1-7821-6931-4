<?php
defined('C5_EXECUTE') or die('Access Denied.');
$this->inc('elements/header.php');
?>

<div id="content">
    <?php
    Loader::element('system_errors', array(
        'error' => $error));
    ?>


    <?php
    echo $innerContent;
    ?>
</div>

<?php $this->inc('elements/footer.php'); ?>

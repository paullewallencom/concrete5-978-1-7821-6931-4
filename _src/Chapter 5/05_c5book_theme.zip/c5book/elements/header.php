<?php
defined('C5_EXECUTE') or die('Access Denied.');
?>
<!DOCTYPE html>
<html lang="<?php echo LANGUAGE ?>">
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=<?php echo APP_CHARSET ?>" /> 
        <link rel="stylesheet" media="screen" type="text/css" href="<?php echo $this->getStyleSheet('main.css') ?>" />

        <?php Loader::element('header_required'); ?>
    </head>
    <?php
    $backgroundAttribute = $c->getAttribute('background');
    if ($backgroundAttribute) {
        $backgroundFile = $backgroundAttribute->getRelativePath();
        echo "<body style=\"background:url('{$backgroundFile}')\">";
    } else {
        echo "<body>";
    }
    ?>


    <div id="wrapper">
        <div id="page">
            <div id="header_line_top"></div>   
            <div id="header">
                <?php
                $autonav = BlockType::getByHandle('autonav');
                $autonav->controller->orderBy = 'display_asc';
                $autonav->controller->displayPages = 'top';
                $autonav->render('templates/header_menu');
                ?>

            </div>
            <div id="header_line_bottom"></div>
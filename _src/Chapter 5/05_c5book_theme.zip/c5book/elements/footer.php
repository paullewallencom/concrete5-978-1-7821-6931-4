<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>

        <div id="footer_line_top"></div>	
        <div id="footer"></div>
        <div id="footer_line_bottom"></div>	
    </div>
</div>

<?php Loader::element('footer_required'); ?>

</body>
</html>

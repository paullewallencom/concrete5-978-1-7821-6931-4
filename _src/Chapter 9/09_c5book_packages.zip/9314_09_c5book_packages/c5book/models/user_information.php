<?php

defined('C5_EXECUTE') or die('Access Denied.');

class UserInformation {

    public function userAdd($ui) {
        $ipv = Loader::helper('validation/ip');
        $ui->setAttribute('ip_address', $ipv->getRequestIP());
    }

}

?>

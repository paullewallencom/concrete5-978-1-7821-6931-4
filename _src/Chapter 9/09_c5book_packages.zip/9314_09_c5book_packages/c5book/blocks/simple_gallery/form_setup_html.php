<?php
defined('C5_EXECUTE') or die('Access Denied.');

echo $form->label('fsID', t('File Set: '));
echo $form->select('fsID', $fileSets, $fsID);

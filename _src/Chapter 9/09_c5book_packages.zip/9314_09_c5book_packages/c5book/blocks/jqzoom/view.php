<div class="ccm-jqzoom">

    <?php
    $html = Loader::helper('html');
    $image = Loader::helper('image');

    $picture = $this->controller->getPicture();

    if ($picture) {
        $bigPicture = $image->getThumbnail($picture, 800, 800)->src;
        $smallPicture = $image->getThumbnail($picture, 200, 200)->src;

        echo "<a class=\"jqzoom\" title=\"{$this->controller->title}\" href=\"{$bigPicture}\">";
        echo "<img src=\"{$smallPicture}\" alt=\"\" title=\"{$this->controller->title}\"/>";
        echo "</a>";
    }
    ?>

</div>

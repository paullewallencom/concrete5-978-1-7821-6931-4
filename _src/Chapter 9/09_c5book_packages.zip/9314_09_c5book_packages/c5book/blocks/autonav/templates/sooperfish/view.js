$(document).ready(function() {
  $('#header > ul').sooperfish({
    hoverClass:    'over',
    delay:         '400ms',
    dualColumn:    7,
    tripleColumn:  14,
    animationShow: {height:'show',opacity:'show'},
    speedShow:     '800ms',
    easingShow:    'easeOutTurbo2',
    animationHide: {width:'hide',opacity:'hide'},
    speedHide:     '400ms',
    easingHide:    'easeOutTurbo',
    autoArrows:    false
  });
});

<?php
defined('C5_EXECUTE') or die('Access Denied.');   

Loader::library('MPDF56/mpdf', 'c5book');
$fh = Loader::helper('file');

$header = <<<EOT
<style type="text/css">
   body { font-family: Helvetica, Arial; }
   h1 { border-bottom: 1px solid black; }
</style>
EOT;

$url = $_REQUEST['p'];
$content = $fh->getContents($url);
$content = preg_replace("/.*<body>|<\/body>.*/si", "", $content);
$content = preg_replace("/<!--hidden_in_pdf_start-->.*?<!--hidden_in_pdf_end-->/siu", "", $content);

$mpdf=new mPDF('utf-8','A4'); 
$mpdf->showImageErrors = true;
$mpdf->SetCreator('PDF by concrete5');
$mpdf->useOnlyCoreFonts = true;
$mpdf->setBasePath($url);
$mpdf->WriteHTML($header . $content);
$mpdf->Output();
?>

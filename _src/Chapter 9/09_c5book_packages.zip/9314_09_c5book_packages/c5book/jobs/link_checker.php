<?php
defined('C5_EXECUTE') or die('Access Denied.');

class LinkChecker extends Job 
{

 public function getJobName() 
 {
  return t("Link Checker");
 }
 
 public function getJobDescription() 
 {
  return t("Checks your site for broken links.");
 }

 /**
  * Returns the HTTP status text for the URL
  * passed in the first argument. Uses cURL 
  * with a 5 second timeout by default and
  * get_headers as a fallback in case cURL
  * isn't installed
  */
 protected function getHttpStatus($url) 
 {
  if (in_array('curl', get_loaded_extensions())) 
  {
   $curl = curl_init();
   
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_HEADER, 1);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);

   $ret = curl_exec($curl);
   curl_close($curl);

   return (strtok($ret, "\n"));    
  }
  else 
  {
   $headers = get_headers($url);
   return $headers[0];         
  }
 }
 
 public function run() 
 {
  Loader::model('page_list');

  $nh = Loader::helper('navigation');
  $db = Loader::db();
  $g = Group::getByID(GUEST_GROUP_ID);
  $linksFound = 0;
  $brokenLinksFound = 0;

  $pl = new PageList();
  $pl->ignoreAliases();

  $regexLinkPattern = 'href=\"([^\"]*)\"';
  $regexStatusPattern = '(.*) ([0-9]{3}) (.*)';

  $pages = $pl->get();

  // delete data from previous runs
  $db->Execute('DELETE FROM btLinkChecker');

  // 1. get all pages
  foreach ($pages as $page) 
  {
   // 2. check permission
   $pk =   PermissionKey::getByHandle('view_page');
   $pk->setPermissionObject($page);
   $pa = $pk->getPermissionAccessObject();
   
   $accessEntities[] = GroupPermissionAccessEntity::getOrCreate($g);
   if ($pk->getPermissionAccessObject() && $pa->validateAccessEntities($accessEntities))
   {      
    $collectionPath = $page->getCollectionPath();

    // 3. get all blocks
    $blocks = $page->getBlocks();
    foreach ($blocks as $block) 
    {

     // 4. only process the output of content blocks
     if ($block->getBlockTypeHandle() == 'content') 
     {
      $bi = $block->getInstance();

      // 5. get all links in the block output
      if(preg_match_all("/{$regexLinkPattern}/siU", $bi->content, 
        $matches, PREG_SET_ORDER))
      {
       foreach($matches as $match) 
       {
        $link = $match[1];
        
        // 6. only track external links
        if (substr($link,0,4) != 'http') 
        {
         break;
        }

        // 7. check link status and save it in btLinkChecker
        $statusHeader = $this->getHttpStatus($link);
        preg_match('/(.*) ([0-9]{3})(.*)/',
          $statusHeader,$statusCodeMatches);

        $statusCode = $statusCodeMatches[2];
        $statusText = $statusCodeMatches[3];

        $linksFound++;

        // we check for 404 and "NULL" which is returned
        // if there's no webserver responding. 404 is 
        // only returned by a running webserver
        if ($statusCode == '404' || !$statusCode) 
        {
         $brokenLinksFound++;
        }
        
        $values = array($page->getCollectionID(), $link, 
          $statusCode, $statusText);
        $db->Execute('INSERT INTO btLinkChecker (cID, link, 
          linkStatusCode, linkStatusName) VALUES (?,?,?,?)', 
          $values);
       }
      }
     }
    }
   }
  }

  return t('Found %d links, out of which %d are broken.', 
   $linksFound, $brokenLinksFound);
 }
}
?>

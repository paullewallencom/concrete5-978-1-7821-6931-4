$(document).ready(function() {
    $("a.lightbox").lightBox({
        imageBtnPrev: CCM_REL + "/blocks/content/templates/lightbox/images/lightbox-btn-prev.gif",
        imageBtnNext: CCM_REL + "/blocks/content/templates/lightbox/images/lightbox-btn-next.gif",
        imageLoading: CCM_REL + "/blocks/content/templates/lightbox/images/lightbox-ico-loading.gif",
        imageBtnClose: CCM_REL + "/blocks/content/templates/lightbox/images/lightbox-btn-close.gif",
        imageBlank: CCM_REL + "/blocks/content/templates/lightbox/images/lightbox-blank.gif"
    });
}); 
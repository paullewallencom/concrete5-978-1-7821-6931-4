$(document).ready(function() {
   $(".ftp-gallery a").lightBox({
      imageBtnPrev: CCM_REL + 
       "/blocks/ftp_gallery/images/lightbox-btn-prev.gif",
      imageBtnNext: CCM_REL + 
       "/blocks/ftp_gallery/images/lightbox-btn-next.gif",
      imageLoading: CCM_REL + 
       "/blocks/ftp_gallery/images/lightbox-ico-loading.gif",
      imageBtnClose: CCM_REL + 
       "/blocks/ftp_gallery/images/lightbox-btn-close.gif",
      imageBlank: CCM_REL + "/blocks/ftp_gallery/images/lightbox-blank.gif",
      fixedNavigation: true,
      overlayBgColor: '#000',
      overlayOpacity: 0.8,
   });
});

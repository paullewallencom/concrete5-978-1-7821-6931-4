<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>
<div class="product-information">
<?php
$html = Loader::helper('html');

$picture = $this->controller->getPicture();

echo "<h2>{$title}</h2>";
if ($picture) {
   echo $html->image($picture->getURL());
}
echo "<p>{$description}</p>";
?>
</div>

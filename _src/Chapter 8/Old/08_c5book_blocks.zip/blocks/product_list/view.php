<hr/>

<?php
defined('C5_EXECUTE') or die(_("Access Denied."));

$nh = Loader::helper('navigation');

$products = $this->controller->getProducts();
foreach ($products as $product) {
   $pageLink = $nh->getLinkToCollection(
      $product->getOriginalCollection());

   echo "<h2>{$product->instance->title}</h2>";
   echo "<a href=\"{$pageLink}\">more...</a>";
   echo "<hr/>";
}
?>

<div class="ad-gallery">
  <div class="ad-image-wrapper">
  </div>
  <div class="ad-controls">
  </div>
  <div class="ad-nav">
    <div class="ad-thumbs">
      <ul class="ad-thumb-list">  
      <?php 
      defined('C5_EXECUTE') or die('Access Denied.');
      
      foreach($images as $imgInfo) {
        $f = File::getByID($imgInfo['fID']);
        $fp = new Permissions($f);
        if ($fp->canRead()) {
      
          $fileName = $f->getFileName();
          $picturePath 	= $f->getRelativePath();
          $thumbnail = $f->getThumbnail(2, false);
          $fileTitle = $f->getAttribute('title');
          $fileDescription = $f->getAttribute('description');
      
          echo "<li>";
          echo "<a title=\"{$fileName}\" href=\"{$picturePath}\">";
          echo "<img src=\"{$thumbnail}\"  title=\"{$fileTitle}\" alt=\"{$fileDescription}\"/>";
          echo "</a>";
          echo "</li>";
        }
      }
      ?>
      </ul>
    </div>
  </div>
</div>

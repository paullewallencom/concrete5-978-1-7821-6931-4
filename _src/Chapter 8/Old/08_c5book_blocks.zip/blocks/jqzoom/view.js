$(document).ready(function(){
   if (!CCM_EDIT_MODE) {
      $('.jqzoom').jqzoom({
         showEffect: 'fadein',
         hideEffect: 'fadeout',
         fadeinSpeed: 'slow',
         fadeoutSpeed: 'normal',
         imageOpacity: 0.25,
         zoomWidth: 200,
         zoomHeight: 200
      });   
   }
});

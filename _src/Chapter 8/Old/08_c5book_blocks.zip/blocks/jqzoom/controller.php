<?php 
defined('C5_EXECUTE') or die('Access Denied. ');
class JqzoomBlockController extends BlockController {
   
   protected $btTable = 'btJqzoom';
   protected $btInterfaceWidth = "590";
   protected $btInterfaceHeight = "450";


   public function getBlockTypeDescription() {
      return t("Embeds a picture magnifier in your page.");
   }
   
   public function getBlockTypeName() {
      return t("jQZoom Picture");
   }
   
   public function getJavaScriptStrings() {
      return array(
         'image-required' => t('You must select an image.')
      );
   }            
   
   function getPicture() {
      if ($this->fIDpicture > 0) {
         return File::getByID($this->fIDpicture);
      }
      return null;
   }
}
?>

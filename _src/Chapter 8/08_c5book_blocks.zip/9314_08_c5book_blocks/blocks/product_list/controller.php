<?php

defined('C5_EXECUTE') or die('Access Denied.');

class ProductListBlockController extends BlockController {

    protected $btTable = 'btProductList';
    protected $btInterfaceWidth = "250";
    protected $btInterfaceHeight = "110";

    public function getBlockTypeDescription() {
        return t("Embeds a Product List in your web page.");
    }

    public function getBlockTypeName() {
        return t("Product List");
    }

    function getCategories() {
        $db = Loader::db();
        return $db->GetAssoc('SELECT categoryID,category FROM btProductInformationCategories ORDER BY category');
    }

    function getProducts() {
        $db = Loader::db();
        $blocks = array();

        // select all block instances which haven't been replaced
        $rs = $db->Execute('SELECT bID FROM btProductInformation bpi 
            WHERE categoryID = ? AND NOT EXISTS (SELECT 1 FROM 
            btProductInformation bpi_sub WHERE bpi.bID=bpi_sub.replacesBlockID)', array($this->categoryID));

        if ($rs) {
            while ($row = $rs->FetchRow()) {
                $blocks[] = Block::getByID($row['bID']);
            }
        }

        return $blocks;
    }

}

?>

<!--hidden_in_pdf_start-->
<?php
defined('C5_EXECUTE') or die(_('Access Denied.'));

$nh = Loader::helper('navigation');
$url = Loader::helper('concrete/urls');

$toolsUrl = $url->getToolsURL('generate_pdf');
$toolsUrl .= '?p=' . rawurlencode($nh->getLinkToCollection($this->c, true));

echo "<a href=\"{$toolsUrl}\">PDF</a>";
?>
<!--hidden_in_pdf_end-->

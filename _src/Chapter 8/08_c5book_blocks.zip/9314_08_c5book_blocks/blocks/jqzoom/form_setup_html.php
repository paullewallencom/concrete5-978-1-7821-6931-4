<?php

defined('C5_EXECUTE') or die('Access Denied.');

$al = Loader::helper('concrete/asset_library');

echo '<div class="ccm-block-field-group">';
echo '<h2>' . t('Title') . '</h2>';
echo $form->text('title', $title, array('style' => 'width: 550px'));
echo '</div>';

echo '<div class="ccm-block-field-group">';
echo '<h2>' . t('Picture') . '</h2>';
echo $al->image('ccm-b-image', 'fIDpicture', t('Choose File'), $this->controller->getPicture());
echo '</div>';
?>

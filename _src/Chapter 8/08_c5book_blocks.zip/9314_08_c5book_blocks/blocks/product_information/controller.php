<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));
class ProductInformationBlockController extends BlockController {
	
	protected $btTable = 'btProductInformation';
	protected $btInterfaceWidth = "590";
	protected $btInterfaceHeight = "450";


	public function getBlockTypeDescription() {
		return t("Embeds a Product Information in your web page.");
	}
	
	public function getBlockTypeName() {
		return t("Product Information");
	}
    
    public function getJavaScriptStrings() {
        return array(
            'image-required' => t('You must select an image.')
        );
    }

    function getCategories() {
        $db = Loader::db();
        return $db->GetAssoc('SELECT categoryID,category FROM btProductInformationCategories ORDER BY category');
    }

	function save($data) { 
		parent::save($data);
	}

    function duplicate($newbID) {
       parent::duplicate($newbID);

       $db = Loader::db();
       $db->Execute('UPDATE btProductInformation SET replacesBlockID=? WHERE bID=?',array($this->bID,$newbID));
    }
	
	function getPicture() {
		if ($this->fIDpicture > 0) {
			return File::getByID($this->fIDpicture);
		}
		return null;
	}

}
?>
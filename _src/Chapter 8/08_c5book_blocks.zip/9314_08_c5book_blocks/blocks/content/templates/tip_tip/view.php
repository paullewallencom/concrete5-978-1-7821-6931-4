<div class="content-tip-tip">
  <?php 
  $bvt = new BlockViewTemplate($b); 
  $bvt->setBlockCustomTemplate(false);

  include($bvt->getTemplate());
  ?>
</div>

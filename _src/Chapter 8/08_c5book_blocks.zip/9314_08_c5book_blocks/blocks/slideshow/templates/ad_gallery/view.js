$(document).ready(function ()  {
    $('.ad-gallery').adGallery({
        loader_image: CCM_REL + "/blocks/slideshow/templates/ad_gallery/css/loader.gif",
        width: 800,
        height: 192,
        animate_first_image: true
    });
});

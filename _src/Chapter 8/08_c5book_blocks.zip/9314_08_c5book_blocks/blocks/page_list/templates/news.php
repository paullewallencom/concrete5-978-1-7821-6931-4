<?php
defined('C5_EXECUTE') or die('Access Denied.');
$th = Loader::helper('text');
$ih = Loader::helper('image');
?>

<div class="ccm-page-list">

    <?php
    foreach ($pages as $page):

        // Prepare data for each page being listed...
        $title = $th->entities($page->getCollectionName());
        $url = $nh->getLinkToCollection($page);
        $target = ($page->getCollectionPointerExternalLink() != '' && $page->openCollectionPointerExternalLinkInNewWindow()) ? '_blank' : $page->getAttribute('nav_target');
        $target = empty($target) ? '_self' : $target;
        $description = $page->getCollectionDescription();
        $description = $controller->truncateSummaries ? $th->shorten($description, $controller->truncateChars) : $description;
        $description = $th->entities($description);

        // get value from thumbnail attribute
        $img = $page->getAttribute('thumbnail');


        // create thumbnail with maximum size 170 × 140
        $thumb = $ih->getThumbnail($img, 170, 140);
        ?>

        <h3 class="ccm-page-list-title">
            <a href="<?php echo $url ?>" target="<?php echo $target ?>"><?php echo $title ?></a>
        </h3>
        <div class="ccm-page-list-thumbnail">
            <img src="<?php echo $thumb->src ?>" width="<?php echo $thumb->width ?>" height="<?php echo $thumb->height ?>" alt=""/>
        </div>
        <div class="ccm-page-list-description">
            <?php echo $description ?>
        </div>

    <?php endforeach; ?>

</div>


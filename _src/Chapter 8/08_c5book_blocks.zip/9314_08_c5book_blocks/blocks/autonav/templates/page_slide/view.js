$(document).ready(function() {
   $("#nav-page-slide-link").pageslide();
});
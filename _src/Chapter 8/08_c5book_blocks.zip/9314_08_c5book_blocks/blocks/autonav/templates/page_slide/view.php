<?php 
$bvt = new BlockViewTemplate($b); 
$bvt->setBlockCustomTemplate(false);

function nav_tree_callback_mobile($buffer) {
   
	return str_replace('<ul class="nav">','<ul class="nav-page-slide">',$buffer);
}

echo '<a id="nav-page-slide-link" href="#nav-page-slide">Navigation</a>';
echo '<div id="nav-page-slide" style="display: none;">';
ob_start("nav_tree_callback_mobile");
include($bvt->getTemplate());
ob_end_flush();
echo '</div>';
?>

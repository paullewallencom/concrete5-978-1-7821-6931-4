<?php

defined('C5_EXECUTE') or die('Access Denied.');

echo '<div class="simple-gallery">';

foreach ($images as $image) {
    $fileName = $image->getFileName();
    $picturePath = $image->getRelativePath();
    $thumbnail = $image->getThumbnail(2, false);

    echo "<a title=\"{$fileName}\" href=\"{$picturePath}\">";
    echo "<img src=\"{$thumbnail}\" />";
    echo "</a>";
}

echo '</div>';
<?php
defined('C5_EXECUTE') or die('Access Denied.');

class SimpleGalleryBlockController extends BlockController {

    protected $btTable = 'btSimpleGallery';
    protected $btInterfaceWidth = "250";
    protected $btInterfaceHeight = "120";

    public function getBlockTypeDescription() {
        return t("Simple picture gallery block.");
    }

    public function getBlockTypeName() {
        return t("Simple Picture Gallery");
    }

    protected function setFileSets() {
        Loader::model('file_set');
        $fileSetsList = FileSet::getMySets();
        $fileSets = array();
        foreach ($fileSetsList as $fileSet) {
            $fileSets[$fileSet->getFileSetID()] = $fileSet->getFileSetName();
        }
        $this->set('fileSets', $fileSets);
    }

    public function edit() {
        $this->setFileSets();
    }

    public function add() {
        $this->setFileSets();
    }

    public function view() {
        $fs = FileSet::getByID($this->fsID);
        $fileList = new FileList();
        $fileList->filterBySet($fs);
        $fileList->filterByType(FileType::T_IMAGE);
        $fileList->sortByFileSetDisplayOrder();

        $images = $fileList->get(1000, 0);
        
        $this->set('images', $images);
    }

}

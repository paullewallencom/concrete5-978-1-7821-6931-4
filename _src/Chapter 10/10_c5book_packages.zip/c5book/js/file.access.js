var currentDirectory = '';
var currentFile = '';

function openDirectory()
{
   $("#directory-structure-waiting").show();
   $("#directory-structure-content").hide();
   $("#directory-structure-up").hide();
   $("#directory-structure-content").html("");

   $.post(CCM_REL + CCM_DISPATCHER_FILENAME + 
   '/tools/packages/c5book/get_structure', {directory: 
    currentDirectory}, function(data) {

      if (data.folders) {
         $.each(data.folders, function(idx, val) {
            $("#directory-structure-content").append("<div class=\"file-access-folder\">"+val+"</div>");
         })         
      }
      if (data.files) {
         $.each(data.files, function(idx, val) {
            $("#directory-structure-content").append("<div class=\"file-access-file\">"+val+"</div>");
         })         
      }

      if (currentDirectory != '') {
         $("#directory-structure-up").show();
      }

      $("#directory-structure-waiting").hide();
      $("#directory-structure-content").show();

   }, 'json');   
}

function openFile(filename) 
{
   currentFile = currentDirectory + filename;

   $("#file-access-waiting").show();
   $("#file-access-content").hide();

   $.post(CCM_REL + CCM_DISPATCHER_FILENAME + 
   '/tools/packages/c5book/get_file',
      {directory: currentDirectory, file: filename}, 
      function(data) {
         $("#file-access-textarea").val(data.fileContent);
         $("#file-access-caption").text(currentFile);
         $("#file-access-content").show();
         $("#file-access-waiting").hide();
      }, 'json');   
}
function fileCancel()
{
   currentFile = '';
   $("#file-access-content").hide();
}
function fileSave()
{
   $("#file-access-waiting").show();
   $("#file-access-content").hide();

   $.post(CCM_REL + CCM_DISPATCHER_FILENAME + 
   '/tools/packages/c5book/save_file',
      {file: currentFile, fileContent: $("#file-access-textarea").val()},
      function (data) {
         $("#file-access-waiting").hide();
      }, 'json');
}

$(document).ready(function() {
   openDirectory();

   $(".file-access-folder").live("click", function() {
      // append selected directory and reload
      currentDirectory += $(this).text() + "/";
      openDirectory();
   })

   $(".file-access-file").live("click", function() {
      openFile($(this).text());
   })

   $("#directory-structure-up").click(function() {
      // remove last directory from path and reload
      currentDirectory = currentDirectory.replace(/[\w]*\/$/,"");
      openDirectory();
   });
})

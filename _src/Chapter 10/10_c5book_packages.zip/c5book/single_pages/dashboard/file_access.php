<?php
defined('C5_EXECUTE') or die('Access Denied.');

echo Loader::helper('concrete/dashboard')->getDashboardPaneHeaderWrapper(
    t('File Access'), t('Manage your site\'s files.'), false, false
);
?>
<div class="ccm-pane-body">
    <div id="directory-structure">
        <div id="directory-structure-waiting"><?php echo t('Please wait...') ?></div>
        <div id="directory-structure-up"><?php echo t('Up') ?></div>
        <div id="directory-structure-content"></div>
    </div>

    <div id="file-access-container">
        <div id="file-access-waiting" style="display:none;">
            <?php echo t('Please wait...') ?>
        </div>
        <div id="file-access-content" style="display:none;">
            <div id="file-access-caption"></div>
            <textarea id="file-access-textarea"></textarea>
            <div id="file-access-toolbar">
                <?php
                $ih = Loader::helper('concrete/interface');
                echo $ih->button_js(t('Save'), 'fileSave()', 'left', 'primary');
                echo $ih->button_js(t('Cancel'), 'fileCancel()', 'left');
                ?>
            </div>         
        </div>
    </div>

    <div style="clear:both"></div>
</div>    
<?php
echo Loader::helper('concrete/dashboard')->getDashboardPaneFooterWrapper(false);
?>
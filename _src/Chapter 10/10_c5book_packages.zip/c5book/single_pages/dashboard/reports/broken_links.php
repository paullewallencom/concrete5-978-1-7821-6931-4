<?php  
defined('C5_EXECUTE') or die('Access Denied.');

echo Loader::helper('concrete/dashboard')->getDashboardPaneHeaderWrapper(
    t('Broken Links'), t('Check your site\'s broken links.'), false, false
);
?>
<div class="ccm-pane-body">
     <?php if ($this->controller->getTask() == 'view'): ?>
 <p><?php echo t('The following links didn\'t return 200 or 302 
   OK / Found. You should check them to make sure they work as 
   expected. Please note: No status code means the server didn\'t 
   respond at all!')?></p>

 <p>
  <a href="<?php echo $this->url
    ('/dashboard/reports/broken_links', 'all')?>">Show All Links
  </a>
 </p>
 <?php else: ?>
 <p><?php echo t('These are all the links found in the content 
    blocks of your site. Click on the link below to display broken 
    links only.')?>
 </p>

 <p>
  <a href="<?php echo $this->url
    ('/dashboard/reports/broken_links')?>">Show Broken Links Only
  </a>
 </p>

 <?php endif; ?>

   <table class="table table-bordered table-striped" > 
    <tr> 
     <td class="header"><?php echo t('Page')?></td> 
     <td class="header"><?php echo t('Link')?></td> 
     <td class="header"><?php echo t('Status')?></td>      
    </tr>
    <?php foreach ($links as $link): ?> 
     <tr> 
      <td>
       <a target="_blank" href="<?php echo $link['page']->getCollectionPath()?>/">
       <?php echo $link['page']->getCollectionName()?>
       </a>
      </td> 
      <td>
       <a target="_blank" href="<?php echo $link['link']?>">
       <?php echo $link['link']?>
       </a>
      </td> 
      <td>
       <?php echo $link['status']?>
      </td>
     </tr> 
     <?php endforeach; ?>
   </table> 
</div>
<?php
echo Loader::helper('concrete/dashboard')->getDashboardPaneFooterWrapper(false);
?>
<?php
defined('C5_EXECUTE') or die('Access Denied.');

class DashboardFileAccessController extends Controller {

    public $helpers = array('form', 'html');

    public function on_start() {
        $html = Loader::helper('html');

        $this->addHeaderItem($html->css('file.access.css', 'c5book'));
        $this->addHeaderItem($html->javascript('file.access.js', 'c5book'));
    }

}
?>

<?php 
defined('C5_EXECUTE') or die('Access Denied. ');

class DashboardReportsBrokenLinksController extends Controller {
   
   public $helpers = array('form', 'html');

   public function view() {
      Loader::model('broken_links', 'c5book');
      $this->set('links', BrokenLinks::getBrokenLinks());
   }
   
   public function all() {
      Loader::model('broken_links', 'c5book');
      $this->set('links', BrokenLinks::getAllLinks());      
   }
}

<?php
defined('C5_EXECUTE') or die('Access Denied.');

class PagePermissionsHelper {
   public static function exitIfNoReadAccess($path) {
      $page = Page::getByPath($path);  
      $permissions = new Permissions($page);

      if (!$permissions->canRead()) {
         die();
      }
   }
}
?>
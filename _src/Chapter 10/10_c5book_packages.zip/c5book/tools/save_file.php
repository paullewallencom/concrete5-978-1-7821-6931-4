<?php
defined('C5_EXECUTE') or die('Access Denied.');    
header('Content-type: text/json');

Loader::helper('page_permissions', 'c5book');
$jh = Loader::helper('json');
PagePermissionsHelper::exitIfNoReadAccess('/dashboard/file_access');

$file = './' . $_REQUEST['file'];

$ret['returnValue'] = file_put_contents($file, $_REQUEST['fileContent']);

echo $jh->encode($ret);
?>

<?php
defined('C5_EXECUTE') or die('Access Denied.');   
header('Content-type: text/json');

Loader::helper('page_permissions', 'c5book');
$jh = Loader::helper('json');
PagePermissionsHelper::exitIfNoReadAccess('/dashboard/file_access');

$files = array();
$folders = array();

$directory = './' . $_REQUEST['directory'];
$file = $_REQUEST['file'];

$ret['fileContent'] = file_get_contents($directory . $file);

echo $jh->encode($ret);
?>

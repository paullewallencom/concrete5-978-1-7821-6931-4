<?php
defined('C5_EXECUTE') or die('Access Denied.');   
header('Content-type: text/json');

Loader::helper('page_permissions', 'c5book');
$jh = Loader::helper('json');
PagePermissionsHelper::exitIfNoReadAccess('/dashboard/file_access');

$ret['items'] = array();
   
$files = array();
$folders = array();   

$directory = './' . $_REQUEST['directory'];
if ($dh = opendir($directory)) {

   while (false !== ($file = readdir($dh))) {

      if ($file == '.' || $file == '..') continue;

      if (is_dir($directory . $file)) {
          $ret['folders'][] = $file;
      }
      else {
          $ret['files'][] = $file;         
      }
    }

    closedir($dh);
}

echo $jh->encode($ret);
?>

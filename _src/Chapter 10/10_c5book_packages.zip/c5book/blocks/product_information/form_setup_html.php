<?php
defined('C5_EXECUTE') or die('Access Denied.');

$al = Loader::helper('concrete/asset_library');

echo '<div class="ccm-block-field-group">';
echo $form->label('title', t('Title'));
echo $form->text('title', $title, array('style' => 'width: 550px'));
echo '</div>';

echo '<div class="ccm-block-field-group">';
echo $form->label('ccm-b-image', t('Picture'));
echo $al->image('ccm-b-image', 'fIDpicture', t('Choose File'), $this->controller->getPicture());
echo '</div>';

echo '<div class="ccm-block-field-group">';
echo $form->label('description', t('Description'));

Loader::element('editor_config');
Loader::element('editor_controls', array('mode' => 'full'));
echo $form->textarea('description', $description, array('class' => 'ccm-advanced-editor'));
echo '</div>';

echo '<div class="ccm-block-field-group">';
echo $form->label('categoryID', t('Category'));
echo $form->select('categoryID', $this->controller->getCategories(), $categoryID);
echo '</div>';

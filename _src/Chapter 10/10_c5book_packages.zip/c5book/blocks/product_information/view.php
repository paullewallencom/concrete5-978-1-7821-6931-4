<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>
<div class="product-information">
<h2><?php echo $title?></h2>
<?php
if ($picture instanceof File) { 
    $html = Loader::helper('html');
    echo $html->image($picture->getURL());
}
?>
<p><?php echo $description?></p>
</div>

<div class="ftp-gallery">
<?php
defined('C5_EXECUTE') or die('Access Denied.');

echo "<h2>{$title}<h2>";

foreach ($pictures as $picture) {
   echo "<a href=\"{$picture['rel_file']}\" 
     title=\"{$picture['file_name']}\"><img 
     src=\"{$picture['thumbnail_rel_file']}\" alt=\"\"/></a>";
}

?>
</div>

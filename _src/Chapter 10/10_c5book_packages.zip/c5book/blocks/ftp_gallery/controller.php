<?php 
defined('C5_EXECUTE') or die('Access Denied.');
class FtpGalleryBlockController extends BlockController {
   
   protected $btTable = 'btFtpGallery';
   protected $btInterfaceWidth = "290";
   protected $btInterfaceHeight = "225";

   public function getBlockTypeDescription() {
      return t("Embeds a Gallery in your web page.");
   }
   
   public function getBlockTypeName() {
      return t("FTP Gallery");
   }

   function view() 
   {
      $this->set('pictures', $this->getPictures());   
   }
   /**
    * Returns a list of all albums (directories)
    * but skips the current and parent folder (. and ..)
    */
   function getAlbums()
   {
      $directories = scandir(DIR_FILES_UPLOADED .
         '/ftp_gallery/');
      $ret = array();
      foreach ($directories as $directory) {
         if ($directory == '.' || $directory == '..') continue;
         $ret[$directory] = $directory;
      }
      return $ret;
   }

   /**
    * Returns all pictures in the currently selected album
    * The return value is an array of a structure with these
    * elements: rel_file, thumbnail_rel_file, file_name
    */
   function getPictures()
   {
      $ih = Loader::helper('image');

      $galleryRelDirectory = DIR_REL . '/files/ftp_gallery/';
      $galleryDirectory = DIR_FILES_UPLOADED . '/ftp_gallery/' . 
      $this->directory . '/';
      $galleryThumbnailDirectory = DIR_FILES_UPLOADED . 
         '/ftp_gallery/' . $this->directory . '/thumbnails/';

      // create thumbnail directory if it doesn't exist
      if (!file_exists($galleryThumbnailDirectory)) {
         mkdir($galleryThumbnailDirectory);
      }

      // get all supported image formats
      $files = glob($galleryDirectory . '*.{jpg,gif,png}', 
      GLOB_BRACE);

      // sort files ascending by modification date
      array_multisort(
          array_map('filemtime',$files),
          SORT_NUMERIC,
          SORT_ASC,
          $files
      );      

      $pictures = array();
      foreach ($files as $file) {
         $pathInfo = pathinfo($file);

         $thumbnailFilename = $pathInfo['filename'] . '_' . 
            $this->thumbnailWidth . '_' . $this->thumbnailHeight .
            '.' . $pathInfo['extension'];
         $thumbnailFile = $galleryThumbnailDirectory . 
            $thumbnailFilename;

         // create thumbnail if it doesn't exist
         if (!file_exists($thumbnailFile)) {
            $ih->create($file, $thumbnailFile,
               $this->thumbnailWidth, 
               $this->thumbnailHeight);
         }

         // build relative paths to files
         $relFile = $galleryRelDirectory . $this->directory . '/' 
         . utf8_encode($pathInfo['basename']);
         $thumbnailRelFile = $galleryRelDirectory . 
            $this->directory . '/thumbnails/' . 
            utf8_encode($thumbnailFilename);
         $fileName = utf8_encode($pathInfo['filename']);

         // create array with all relevant data we have to process
         // in view.php
         $pictures[] = array(
            'rel_file' => $relFile,
            'thumbnail_rel_file' => $thumbnailRelFile,
            'file_name' => $fileName
            );
      }
      return $pictures;
   }
}
?>

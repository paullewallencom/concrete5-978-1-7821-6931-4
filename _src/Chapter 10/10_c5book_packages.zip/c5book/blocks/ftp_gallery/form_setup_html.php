<?php

defined('C5_EXECUTE') or die('Access Denied.');

// set default value when adding a new block instance
if (!$thumbnailWidth || $thumbnailWidth < 1)
    $thumbnailWidth = 180;
if (!$thumbnailHeight || $thumbnailHeight < 1)
    $thumbnailHeight = 120;

echo '<div class="ccm-block-field-group">';
echo '<h2>' . t('Title') . '</h2>';
echo $form->text('title', $title, array('style' => 'width: 255px'));
echo '</div>';

echo '<div class="ccm-block-field-group">';
echo '<h2>' . t('Directory') . '</h2>';
echo $form->select('directory', $this->controller->getAlbums(), $directory, array('style' => 'width:265px;'));
echo '</div>';

echo '<div class="ccm-block-field-group">';
echo '<h2>' . t('Thumbnail Dimension') . '</h2>';
echo $form->label('labelThumbnailWidth', 'Width (px) ');
echo $form->text('thumbnailWidth', $thumbnailWidth, array('style' => 'width: 60px'));
echo $form->label('labelThumbnailHeight', ' Height (px) ');
echo $form->text('thumbnailHeight', $thumbnailHeight, array('style' => 'width: 60px'));
echo '</div>';
?>

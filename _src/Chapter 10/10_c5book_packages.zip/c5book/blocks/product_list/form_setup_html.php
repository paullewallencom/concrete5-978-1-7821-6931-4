<?php
defined('C5_EXECUTE') or die('Access Denied.');

$al = Loader::helper('concrete/asset_library');

echo '<div class="ccm-block-field-group">';
echo '<h2>' . t('Category') . '</h2>';
echo $form->select('categoryID',
   $this->controller->getCategories(),
   $categoryID, 
   array('style' => 'width:235px;'));
echo '</div>';
?>

<hr/>

<?php
defined('C5_EXECUTE') or die('Access Denied.');

$nh = Loader::helper('navigation');

foreach ($products as $product) {
   $pageLink = $nh->getLinkToCollection(
      $product->getOriginalCollection());

   echo "<h2>{$product->instance->title}</h2>";
   echo "<a href=\"{$pageLink}\">more...</a>";
   echo "<hr/>";
}
<?php 
defined('C5_EXECUTE') or die('Access Denied.');
class PdfBlockController extends BlockController {
   
   protected $btInterfaceWidth = "200";
   protected $btInterfaceHeight = "140";

   public function getBlockTypeDescription() {
      return t("Add a PDF-Generation link in your web page.");
   }
   
   public function getBlockTypeName() {
      return t("PDF Generator");
   }
}
?>

<?php
defined('C5_EXECUTE') or die('Access Denied.');

class BrokenLinks {
  public static function add($cID, $link, $statusCode, 
  $statusName) {
      $db = Loader::db();

      $values = array($cID, $link, $statusCode, $statusName);
      $db->Execute('INSERT INTO LinkChecker (cID, link, 
      linkStatusCode, linkStatusName) VALUES (?,?,?,?)', $values);      
   }

   public static function deleteAll() {
      $db = Loader::db();
      
      $db->Execute('DELETE FROM LinkChecker');
   }

   public static function getBrokenLinks($includeDetails=true) {
      $query = 'SELECT * FROM LinkChecker WHERE linkStatusCode 
      NOT IN (200,302) OR linkStatusCode IS NULL';
      return BrokenLinks::getLinksInternal($query, 
      $includeDetails);
   }

   public static function getAllLinks($includeDetails=true) {
      $query = 'SELECT * FROM LinkChecker';
      return BrokenLinks::getLinksInternal($query, 
      $includeDetails);
   }

   private static function getLinksInternal($query, 
   $includeDetails=true) {
      $db = Loader::db();

      $brokenLinks = array();
      $result = $db->Execute($query);
      while ($row = $result->FetchRow()) {         
         if ($includeDetails) {
            $row['page'] = Page::getByID($row['cID']);
            $row['status'] = $row['linkStatusCode'] . ' ' . 
            $row['linkStatusName'];
            if (trim($row['status']) == '') $row['status'] = 
            'Server not found';            
         }

         $brokenLinks[] = $row;
      }      

      return $brokenLinks;
   }
}
?>

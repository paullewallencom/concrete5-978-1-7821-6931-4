<?php

defined('C5_EXECUTE') or die('Access Denied.');

class c5bookPackage extends Package {

    protected $pkgHandle = 'c5book';
    protected $appVersionRequired = '5.6.0';
    protected $pkgVersion = '1.0';

    public function getPackageDescription() {
        return t("Theme, Templates and Blocks from concrete5 for Beginner's");
    }

    public function getPackageName() {
        return t("c5book");
    }

    public function install() {
        $pkg = parent::install();

        // add attributes
        UserAttributeKey::add('text', array('akHandle' => 'ip_address', 'akName' => t('IP Address')), $pkg);

        // install blocks
        BlockType::installBlockTypeFromPackage('jqzoom', $pkg);
        BlockType::installBlockTypeFromPackage('pdf', $pkg);
        BlockType::installBlockTypeFromPackage('ftp_gallery', $pkg);
        BlockType::installBlockTypeFromPackage('product_information', $pkg);
        BlockType::installBlockTypeFromPackage('product_list', $pkg);

        // install link checker job
        Loader::model("job");
        Job::installByPackage("link_checker", $pkg);

        // install single pages 
        Loader::model('single_page');
        $sp = SinglePage::add('/dashboard/reports/broken_links', $pkg);        
        if (version_compare(APP_VERSION, '5.6', '>')) {
            $sp->setAttribute('icon_dashboard', 'icon-warning-sign');
        }
        $sp = SinglePage::add('/dashboard/file_access', $pkg);        
        if (version_compare(APP_VERSION, '5.6', '>')) {
            $sp->setAttribute('icon_dashboard', 'icon-file');
        }
    }

    function on_start() {
        $html = Loader::helper('html');

        // inform about new users
        Events::extend('on_user_add', 'UserInformation', 'userAdd', 'packages/' . $this->pkgHandle . '/models/user_information.php');

        // replace native tooltip with TipTip
        $v = View::getInstance();
        $v->addHeaderItem($html->javascript('jquery.tipTip.minified.js', 'c5book'));
        $v->addHeaderItem($html->css('tipTip.css', 'c5book'));
        $v->addHeaderItem('<script type="text/javascript">$(function(){ $("[title]").tipTip(); });</script>');

        // include MSIE fix
        $v->addHeaderItem('<!--[if lt IE 8]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE8.js"></script><![endif]-->');        
    }

}
?>

$(function(){
    $(".content-tip-tip [title]").tipTip();
});

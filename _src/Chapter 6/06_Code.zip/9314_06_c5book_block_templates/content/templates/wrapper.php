<div class="content-wrapper">
<?php 
$bvt = new BlockViewTemplate($b); 
$bvt->setBlockCustomTemplate(false);

include($bvt->getTemplate());
?>
</div>

<div class="ccm-slideshow-gallery">
<?php 
defined('C5_EXECUTE') or die('Access Denied.');

foreach($images as $imgInfo) {
  $f = File::getByID($imgInfo['fID']);
  $fp = new Permissions($f);
  if ($fp->canViewFile()) {

    $fileName = $f->getFileName();
    $picturePath = $f->getRelativePath();
    $thumbnail = $f->getThumbnail(2);

    echo "<a title=\"{$fileName}\" 
      href=\"{$picturePath}\">{$thumbnail}</a>";
  }
}
?>
</div>
$(document).ready(function() {
    $(".ccm-slideshow-gallery a").lightBox({
        imageBtnPrev: CCM_REL + "/blocks/slideshow/templates/gallery/images/lightbox-btn-prev.gif",
        imageBtnNext: CCM_REL +  "/blocks/slideshow/templates/gallery/images/lightbox-btn-next.gif",
        imageLoading: CCM_REL +  "/blocks/slideshow/templates/gallery/images/lightbox-ico-loading.gif",
        imageBtnClose: CCM_REL +  "/blocks/slideshow/templates/gallery/images/lightbox-btn-close.gif",
        imageBlank: CCM_REL + "/blocks/slideshow/templates/gallery/images/lightbox-blank.gif"
    });
});
